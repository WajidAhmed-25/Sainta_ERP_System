import React from 'react'

const Product_Management = () => {
  return (
    <div>

    </div>
  )
}

export default Product_Management
