
// import React, { useState, useContext } from 'react';
// import { useTranslation } from 'react-i18next';
// import { useAuth } from '../AuthContext';

// const Navbar = () => {
//   const [isOpen, setIsOpen] = useState(false);
//   const { t } = useTranslation();


//   const { isAuthenticated } = useAuth();

//   const toggleMenu = () => {
//     setIsOpen(!isOpen);
//   };

//   return (
//     <div className=''>
//       <nav className="p-4 shadow-xl" style={{ background: 'linear-gradient(to right, #f4fcfe 0%, #f4fcfe 100%)' }}>
//         <div className="container flex flex-col items-center justify-between mx-auto lg:flex-row">
        
          
//           {/* If logged in, show login success message */}
//           {isAuthenticated ? (
// <>
// <div className="flex items-center w-full  justify-center mb-4 text-3xl font-bold text-center text-[#007AAF] lg:mb-0 hover:cursor-pointer">
//   <p className='text-center'>  {t('navbar.brand')} </p>
// </div>

// </>
//           ) : (
//             <>
//               <div className="mb-4 lg:pl-20  text-2xl font-bold sm:pl-0 text-[#007AAF] lg:mb-0 hover:cursor-pointer">
//             {t('navbar.brand')}
//           </div>
//               {/* Burger Button */}
//               <div className="lg:hidden">
//                 <button
//                   onClick={toggleMenu}
//                   className="text-[#007AAF] focus:outline-none"
//                   aria-label="Toggle menu"
//                 >
//                   <svg
//                     className="w-6 h-6"
//                     fill="none"
//                     stroke="currentColor"
//                     viewBox="0 0 24 24"
//                     xmlns="http://www.w3.org/2000/svg"
//                   >
//                     <path
//                       strokeLinecap="round"
//                       strokeLinejoin="round"
//                       strokeWidth="2"
//                       d="M4 6h16M4 12h16m-7 6h7"
//                     ></path>
//                   </svg>
//                 </button>
//               </div>

//               {/* Menu Items */}
//               <div
//                 className={`lg:flex flex-col lg:flex-row lg:space-x-12 lg:mt-0 mt-4 mr-4 flex items-center sm:mr-0 text-xl ${
//                   isOpen ? '' : 'hidden'
//                 }`}
//               >
//                 <button
//                   onClick={toggleMenu}
//                   className="absolute text-3xl text-[#007AAF] lg:hidden top-4 right-4"
//                   aria-label="Close menu"
//                 >
//                   <svg
//                     className="w-6 h-6"
//                     fill="none"
//                     stroke="currentColor"
//                     viewBox="0 0 24 24"
//                     xmlns="http://www.w3.org/2000/svg"
//                   >
//                     <path
//                       strokeLinecap="round"
//                       strokeLinejoin="round"
//                       strokeWidth="2"
//                       d="M6 18L18 6M6 6l12 12"
//                     ></path>
//                   </svg>
//                 </button>

//                 <a href="/" className="px-4 py-2 text-[#007AAF] hover:scale-110 transition-all duration-300">
//                   {t('navbar.strengths')}
//                 </a>
//                 <a href="#Projects" className="px-4 py-2 text-[#007AAF] hover:scale-110 transition-all duration-300">
//                   {t('navbar.features')}
//                 </a>
//                 <a href="/" className="px-4 py-2 text-[#007AAF] hover:scale-110 transition-all duration-300">
//                   {t('navbar.registration')}
//                 </a>
//                 <a href="/" className="px-4 py-2 text-[#007AAF] hover:scale-110 transition-all duration-300">
//                   {t('navbar.costs')}
//                 </a>
//               </div>
//             </>
//           )}
//         </div>
//       </nav>
//     </div>
//   );
// };

// export default Navbar;
































// import React, { useState, useContext } from 'react';
// import { useTranslation } from 'react-i18next';
// import { useAuth } from '../AuthContext';

// const Navbar = () => {
//   const [isOpen, setIsOpen] = useState(false);
//   const { t } = useTranslation();


  

//   const toggleMenu = () => {
//     setIsOpen(!isOpen);
//   };

//   return (
//     <div className=''>
//       <nav className="p-4 shadow-xl" style={{ background: 'linear-gradient(to right, #f4fcfe 0%, #f4fcfe 100%)' }}>
//         <div className="container flex flex-col items-center justify-between mx-auto lg:flex-row">
        
      
//               <div className="mb-4 lg:pl-20  text-2xl font-bold sm:pl-0 text-[#007AAF] lg:mb-0 hover:cursor-pointer">
//             {t('navbar.brand')}
//           </div>
//               {/* Burger Button */}
//               <div className="lg:hidden">
//                 <button
//                   onClick={toggleMenu}
//                   className="text-[#007AAF] focus:outline-none"
//                   aria-label="Toggle menu"
//                 >
//                   <svg
//                     className="w-6 h-6"
//                     fill="none"
//                     stroke="currentColor"
//                     viewBox="0 0 24 24"
//                     xmlns="http://www.w3.org/2000/svg"
//                   >
//                     <path
//                       strokeLinecap="round"
//                       strokeLinejoin="round"
//                       strokeWidth="2"
//                       d="M4 6h16M4 12h16m-7 6h7"
//                     ></path>
//                   </svg>
//                 </button>
//               </div>

//               {/* Menu Items */}
//               <div
//                 className={`lg:flex flex-col lg:flex-row lg:space-x-12 lg:mt-0 mt-4 mr-4 flex items-center sm:mr-0 text-xl ${
//                   isOpen ? '' : 'hidden'
//                 }`}
//               >
//                 <button
//                   onClick={toggleMenu}
//                   className="absolute text-3xl text-[#007AAF] lg:hidden top-4 right-4"
//                   aria-label="Close menu"
//                 >
//                   <svg
//                     className="w-6 h-6"
//                     fill="none"
//                     stroke="currentColor"
//                     viewBox="0 0 24 24"
//                     xmlns="http://www.w3.org/2000/svg"
//                   >
//                     <path
//                       strokeLinecap="round"
//                       strokeLinejoin="round"
//                       strokeWidth="2"
//                       d="M6 18L18 6M6 6l12 12"
//                     ></path>
//                   </svg>
//                 </button>

//                 <a href="/" className="px-4 py-2 text-[#007AAF] hover:scale-110 transition-all duration-300">
//                   {t('navbar.strengths')}
//                 </a>
//                 <a href="#Projects" className="px-4 py-2 text-[#007AAF] hover:scale-110 transition-all duration-300">
//                   {t('navbar.features')}
//                 </a>
//                 <a href="/" className="px-4 py-2 text-[#007AAF] hover:scale-110 transition-all duration-300">
//                   {t('navbar.registration')}
//                 </a>
//                 <a href="/" className="px-4 py-2 text-[#007AAF] hover:scale-110 transition-all duration-300">
//                   {t('navbar.costs')}
//                 </a>
//               </div>
        
//         </div>
//       </nav>
//     </div>
//   );
// };

// export default Navbar;























import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const { t } = useTranslation();
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    // Check if 'username' exists in local storage
    const username = localStorage.getItem('username');
    if (username) {
      setIsAuthenticated(true);
    }
  }, []);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  return (
    <div>
      <nav className="p-4 shadow-xl" style={{ background: 'linear-gradient(to right, #f4fcfe 0%, #f4fcfe 100%)' }}>
        <div className={`container mx-auto flex ${isAuthenticated ? 'justify-center ' : 'justify-between'} flex-col lg:flex-row items-center`}>
          <div className={` ${isAuthenticated ? 'text-3xl ' : 'text-2xl'} ${isAuthenticated ? 'ml-0 ' : 'ml-4'} font-bold text-[#007AAF] hover:cursor-pointer`}>
            {isAuthenticated ? 'Sainta ERP' : t('navbar.brand')}
          </div>

          {/* Check if user is authenticated */}
          {!isAuthenticated && (
            <>
              {/* Burger Button */}
              <div className="lg:hidden">
                <button
                  onClick={toggleMenu}
                  className="text-[#007AAF] focus:outline-none"
                  aria-label="Toggle menu"
                >
                  <svg
                    className="w-6 h-6"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M4 6h16M4 12h16m-7 6h7"
                    ></path>
                  </svg>
                </button>
              </div>

              {/* Menu Items */}
              <div
                className={`lg:flex flex-col lg:flex-row lg:space-x-12 lg:mt-0 mt-4 mr-4 flex items-center sm:mr-0 text-xl ${
                  isOpen ? '' : 'hidden'
                }`}
              >
                <button
                  onClick={toggleMenu}
                  className="absolute text-3xl text-[#007AAF] lg:hidden top-4 right-4"
                  aria-label="Close menu"
                >
                  <svg
                    className="w-6 h-6"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M6 18L18 6M6 6l12 12"
                    ></path>
                  </svg>
                </button>

                <a href="/" className="px-4 py-2 text-[#007AAF] hover:scale-110 transition-all duration-300">
                  {t('navbar.strengths')}
                </a>
                <a href="#Projects" className="px-4 py-2 text-[#007AAF] hover:scale-110 transition-all duration-300">
                  {t('navbar.features')}
                </a>
                <a href="/" className="px-4 py-2 text-[#007AAF] hover:scale-110 transition-all duration-300">
                  {t('navbar.registration')}
                </a>
                <a href="/" className="px-4 py-2 text-[#007AAF] hover:scale-110 transition-all duration-300">
                  {t('navbar.costs')}
                </a>
              </div>
            </>
          )}
        </div>
      </nav>
    </div>
  );
};

export default Navbar;

















